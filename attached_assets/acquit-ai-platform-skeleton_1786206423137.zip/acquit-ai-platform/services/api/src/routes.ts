export const routes = {
  cases: {
    create: "POST /api/cases",
    get: "GET /api/cases/:caseId",
    update: "PATCH /api/cases/:caseId"
  },
  ai: {
    run: "POST /api/ai/agents/:agentId/runs",
    stream: "GET /api/ai/runs/:runId/stream"
  },
  research: {
    search: "POST /api/research/search"
  },
  documents: {
    upload: "POST /api/documents",
    get: "GET /api/documents/:documentId"
  },
  court: {
    connections: "GET /api/court/connections",
    searchCases: "POST /api/court/:connectorId/search",
    docket: "GET /api/court/:connectorId/cases/:externalCaseId/docket",
    submitFiling: "POST /api/court/:connectorId/filings"
  }
} as const;
