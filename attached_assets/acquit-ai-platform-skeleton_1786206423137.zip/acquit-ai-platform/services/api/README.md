# API Service

Authenticated boundary between the client and platform services.

Recommended modules:
- cases
- documents
- research
- agents
- filings
- court-connectors
- audit
