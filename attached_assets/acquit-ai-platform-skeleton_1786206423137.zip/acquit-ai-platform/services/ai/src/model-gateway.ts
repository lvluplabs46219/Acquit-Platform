import type {
  ModelAdapter, ModelGateway, ModelProvider, ModelRequest, ModelResponse, ModelStreamEvent
} from "@acquit/model-gateway";

export class DefaultModelGateway implements ModelGateway {
  private adapters = new Map<ModelProvider, ModelAdapter>();

  register(adapter: ModelAdapter): void {
    this.adapters.set(adapter.provider, adapter);
  }

  async resolve(provider: ModelProvider, _model: string): Promise<ModelAdapter> {
    const adapter = this.adapters.get(provider);
    if (!adapter) throw new Error(`Model provider not registered: ${provider}`);
    return adapter;
  }

  async complete(request: ModelRequest): Promise<ModelResponse> {
    const provider = request.provider ?? "ollama";
    return (await this.resolve(provider, request.model)).complete(request);
  }

  stream(request: ModelRequest): AsyncIterable<ModelStreamEvent> {
    const provider = request.provider ?? "ollama";
    const adapterPromise = this.resolve(provider, request.model);
    return this.streamFromAdapter(adapterPromise, request);
  }

  private async *streamFromAdapter(
    adapterPromise: Promise<ModelAdapter>,
    request: ModelRequest
  ): AsyncIterable<ModelStreamEvent> {
    const adapter = await adapterPromise;
    yield* adapter.stream(request);
  }
}
