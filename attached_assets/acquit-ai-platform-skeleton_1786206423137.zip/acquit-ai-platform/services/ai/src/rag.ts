import type { RagEngine, SearchQuery } from "@acquit/rag";

export async function retrieveLegalContext(
  rag: RagEngine,
  query: SearchQuery
) {
  return rag.buildContext({
    ...query,
    mode: query.mode ?? "hybrid"
  });
}
