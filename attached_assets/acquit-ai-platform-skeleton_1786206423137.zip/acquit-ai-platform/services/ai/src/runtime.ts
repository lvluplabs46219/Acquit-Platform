import type { AgentRuntime, AgentRequest, AgentEvent } from "@acquit/agent-sdk";

export class AcquitAgentRuntime implements AgentRuntime {
  async *execute(request: AgentRequest): AsyncIterable<AgentEvent> {
    yield { type: "run.started", runId: request.context.runId };
    yield { type: "reasoning.status", message: "Preparing evidence-grounded response." };
    // TODO:
    // 1. authorize agent/tool permissions
    // 2. retrieve jurisdiction-specific sources
    // 3. call ModelGateway
    // 4. validate citations and disclaimer
    // 5. persist audit trail
    yield {
      type: "run.failed",
      error: { code: "NOT_IMPLEMENTED", message: "AI runtime adapter not wired yet." }
    };
  }
}
