# AI Service

Responsible for:
- model routing
- agent execution
- RAG retrieval
- tool authorization
- citation/provenance enforcement
- safety policy evaluation
- model/provider observability

The service must not let an agent directly execute arbitrary external actions.
External actions require explicit tool permissions and an auditable execution record.
