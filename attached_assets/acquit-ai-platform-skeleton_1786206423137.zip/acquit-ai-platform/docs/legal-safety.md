# Legal Safety Contract

The platform is designed to provide legal information and self-representation support, not to falsely represent itself as a licensed attorney.

High-risk actions require additional controls:
- filing/submitting documents
- making decisions for a user
- plea recommendations
- predicting case outcomes
- contacting a court or opposing party

For plea support specifically:
- explain options and factors;
- provide questions to discuss with counsel;
- do not say "you should accept/reject";
- do not claim to predict trial outcomes.

Required disclaimer:

"This information is for educational purposes only and does not constitute legal advice. Consult a licensed attorney in your jurisdiction."
