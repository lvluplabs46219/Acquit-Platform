# Acquit.ai Architecture

```text
Browser
  |
  v
Web App
  |
  v
Authenticated API
  |
  +--------------------+
  |                    |
  v                    v
Case/Document DB     AI Runtime
  |                    |
  |              +-----+--------+
  |              |              |
  |          Agent SDK      Model Gateway
  |              |              |
  |              v       Ollama / llama.cpp /
  |             RAG      Hugging Face / hosted APIs
  |              |
  +----------> Legal Sources
                     |
                     +--> Court Connector SDK
                     +--> Public case-law sources
                     +--> User documents
```

## Security boundaries

1. Browser has no model/provider secrets.
2. Every case/document access is authorized against the authenticated user.
3. Agents receive explicit tool permissions.
4. Court submission is a separate high-risk capability from drafting.
5. Retrieval records the source and retrieval trace.
6. AI runs record model/provider/version and prompt hashes.
7. PII is excluded from operational logs.
