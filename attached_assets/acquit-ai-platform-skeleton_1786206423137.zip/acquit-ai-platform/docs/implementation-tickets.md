# Initial Implementation Tickets

## P0 — Foundation

- [ ] DB-001 Apply migrations and verify RLS.
- [ ] DB-002 Add typed database client.
- [ ] API-001 Implement authentication middleware.
- [ ] API-002 Implement case CRUD.
- [ ] SEC-001 Add audit-event pipeline.
- [ ] SEC-002 Add document malware scanning and private storage.

## P1 — AI Core

- [ ] AI-001 Implement Model Gateway.
- [ ] AI-002 Add Ollama adapter.
- [ ] AI-003 Add llama.cpp OpenAI-compatible adapter.
- [ ] AI-004 Add Hugging Face adapter.
- [ ] AGENT-001 Implement AgentRuntime.
- [ ] AGENT-002 Implement tool permission engine.
- [ ] AGENT-003 Implement multi-agent delegation.
- [ ] RAG-001 Implement chunking.
- [ ] RAG-002 Implement pgvector embeddings.
- [ ] RAG-003 Implement hybrid search.
- [ ] RAG-004 Implement citation verifier.

## P2 — Legal Library

- [ ] LIB-001 Source registry.
- [ ] LIB-002 Case-law ingestion.
- [ ] LIB-003 Statute/rule ingestion.
- [ ] LIB-004 Motion/document library.
- [ ] LIB-005 Source freshness tracking.

## P3 — Court Connectivity

- [ ] COURT-001 Connector registry.
- [ ] COURT-002 Public case search connector.
- [ ] COURT-003 Docket synchronization.
- [ ] COURT-004 Document retrieval.
- [ ] COURT-005 Filing preparation.
- [ ] COURT-006 E-filing adapters only where authorized and technically supported.

## P4 — Safety / Evaluation

- [ ] QA-001 Citation-required evaluation.
- [ ] QA-002 Hallucination benchmark.
- [ ] QA-003 Prompt-injection benchmark.
- [ ] QA-004 Unauthorized-tool-use benchmark.
- [ ] QA-005 RLS cross-user tests.
- [ ] QA-006 High-risk plea/filing guardrails.
