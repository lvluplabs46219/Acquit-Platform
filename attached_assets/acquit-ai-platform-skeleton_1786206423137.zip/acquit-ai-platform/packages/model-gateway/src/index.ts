export type ModelProvider =
  | "openai"
  | "anthropic"
  | "ollama"
  | "llamacpp"
  | "huggingface"
  | "custom";

export interface ChatMessage {
  role: "system" | "user" | "assistant" | "tool";
  content: string;
  name?: string;
  toolCallId?: string;
}

export interface ModelRequest {
  provider?: ModelProvider;
  model: string;
  messages: ChatMessage[];
  temperature?: number;
  maxTokens?: number;
  responseFormat?: "text" | "json";
  tools?: ModelTool[];
  metadata?: Record<string, string>;
}

export interface ModelTool {
  name: string;
  description: string;
  inputSchema: unknown;
}

export interface ModelResponse {
  id: string;
  provider: ModelProvider;
  model: string;
  content: string;
  finishReason: "stop" | "length" | "tool_call" | "error";
  usage: { inputTokens: number; outputTokens: number; totalTokens: number };
  toolCalls?: Array<{ id: string; name: string; arguments: unknown }>;
  rawProviderMetadata?: Record<string, unknown>;
}

export interface ModelStreamEvent {
  type: "delta" | "tool_call" | "usage" | "done" | "error";
  text?: string;
  toolCall?: { id: string; name: string; arguments: unknown };
  usage?: ModelResponse["usage"];
  error?: { code: string; message: string };
}

export interface ModelAdapter {
  provider: ModelProvider;
  listModels(): Promise<string[]>;
  complete(request: ModelRequest): Promise<ModelResponse>;
  stream(request: ModelRequest): AsyncIterable<ModelStreamEvent>;
  health(): Promise<{ ok: boolean; latencyMs?: number; details?: string }>;
}

export interface ModelGateway {
  register(adapter: ModelAdapter): void;
  resolve(provider: ModelProvider, model: string): Promise<ModelAdapter>;
  complete(request: ModelRequest): Promise<ModelResponse>;
  stream(request: ModelRequest): AsyncIterable<ModelStreamEvent>;
}
