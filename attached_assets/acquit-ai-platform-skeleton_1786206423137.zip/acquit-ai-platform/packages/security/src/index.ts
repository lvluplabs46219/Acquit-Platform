export interface AuthorizationContext {
  userId: string;
  tenantId?: string;
  roles: string[];
  caseId?: string;
}

export interface AuditEvent {
  actorUserId?: string;
  action: string;
  resourceType: string;
  resourceId?: string;
  outcome: "allowed" | "denied" | "success" | "failure";
  metadata: Record<string, unknown>;
  occurredAt: string;
}

export interface Redactor {
  redactText(text: string): string;
  hashIdentifier(value: string): string;
}

export const LEGAL_INFORMATION_DISCLAIMER =
  "This information is for educational purposes only and does not constitute legal advice. Consult a licensed attorney in your jurisdiction.";
