import type { AgentRole, LegalCase, SourceCitation, UUID } from "@acquit/contracts";

export interface AgentDefinition {
  id: string;
  version: string;
  name: string;
  role: AgentRole;
  description: string;
  systemPolicy: AgentPolicy;
  tools: AgentToolDefinition[];
  requiredCapabilities: string[];
  outputSchema: string;
}

export interface AgentPolicy {
  mayProvideLegalInformation: boolean;
  mayRecommendLegalStrategy: boolean;
  mayMakeFinalLegalDecision: boolean;
  mayFileOrSubmitDocuments: boolean;
  mustUseRagForLegalClaims: boolean;
  mustCiteMaterialClaims: boolean;
  disclaimerRequired: boolean;
}

export interface AgentToolDefinition {
  name: string;
  description: string;
  permission: ToolPermission;
  inputSchema: unknown;
  outputSchema: unknown;
}

export type ToolPermission =
  | "read_case"
  | "read_documents"
  | "search_legal_sources"
  | "draft_document"
  | "prepare_filing"
  | "submit_filing"
  | "read_court_status"
  | "custom";

export interface AgentContext {
  runId: UUID;
  userId: UUID;
  case?: LegalCase;
  jurisdictionId?: UUID;
  conversationId?: UUID;
  parentAgentRunId?: UUID;
  requestedTask: string;
  memory: AgentMemory;
}

export interface AgentMemory {
  facts: Record<string, unknown>;
  decisions: Array<{ key: string; value: unknown; source?: SourceCitation }>;
  priorMessages: Array<{ role: "user" | "assistant" | "system"; content: string }>;
}

export interface AgentRequest {
  agent: AgentDefinition;
  context: AgentContext;
  input: string;
  attachments?: UUID[];
  temperature?: number;
  maxOutputTokens?: number;
}

export interface AgentResponse {
  runId: UUID;
  status: "completed" | "needs_input" | "blocked" | "failed";
  output: string;
  citations: SourceCitation[];
  disclaimer: string;
  toolCalls: ToolCallResult[];
  confidence?: number;
}

export interface ToolCallRequest {
  name: string;
  permission: ToolPermission;
  arguments: unknown;
}

export interface ToolCallResult {
  name: string;
  status: "success" | "denied" | "failed";
  output?: unknown;
  error?: string;
}

export interface AgentRuntime {
  execute(request: AgentRequest): AsyncIterable<AgentEvent>;
}

export type AgentEvent =
  | { type: "run.started"; runId: UUID }
  | { type: "reasoning.status"; message: string }
  | { type: "retrieval.started"; query: string }
  | { type: "retrieval.completed"; citationCount: number }
  | { type: "tool.requested"; call: ToolCallRequest }
  | { type: "tool.completed"; result: ToolCallResult }
  | { type: "output.delta"; text: string }
  | { type: "run.completed"; response: AgentResponse }
  | { type: "run.failed"; error: { code: string; message: string } };
