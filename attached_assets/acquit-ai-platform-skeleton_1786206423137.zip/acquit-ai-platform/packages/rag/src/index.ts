import type { SourceCitation, UUID } from "@acquit/contracts";

export type SearchMode = "keyword" | "semantic" | "hybrid";

export interface EmbeddingProvider {
  model: string;
  dimensions: number;
  embed(text: string): Promise<number[]>;
  embedBatch(texts: string[]): Promise<number[][]>;
}

export interface SearchQuery {
  query: string;
  caseId?: UUID;
  jurisdictionId?: UUID;
  mode: SearchMode;
  topK: number;
  filters?: Record<string, unknown>;
}

export interface RetrievedChunk {
  id: UUID;
  documentId: UUID;
  chunkIndex: number;
  text: string;
  score: number;
  source: SourceCitation;
  metadata: Record<string, unknown>;
}

export interface Reranker {
  rerank(query: string, chunks: RetrievedChunk[], topK: number): Promise<RetrievedChunk[]>;
}

export interface RagEngine {
  ingest(input: IngestionInput): Promise<IngestionResult>;
  search(query: SearchQuery): Promise<RetrievedChunk[]>;
  buildContext(query: SearchQuery): Promise<RagContext>;
}

export interface IngestionInput {
  documentId: UUID;
  text: string;
  source: SourceCitation;
  metadata?: Record<string, unknown>;
}

export interface IngestionResult {
  documentId: UUID;
  chunkCount: number;
  embeddedCount: number;
  embeddingModel: string;
}

export interface RagContext {
  query: string;
  chunks: RetrievedChunk[];
  citations: SourceCitation[];
  contextText: string;
  retrievalTraceId: UUID;
}
