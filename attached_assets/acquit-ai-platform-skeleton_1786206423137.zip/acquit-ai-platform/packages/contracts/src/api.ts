import type { UUID } from "./index";

export interface CreateCaseRequest {
  jurisdictionId: UUID;
  title: string;
  caseNumber?: string;
  caseType?: string;
}

export interface AgentRunRequest {
  caseId?: UUID;
  agentId: string;
  input: string;
  attachmentIds?: UUID[];
  idempotencyKey: string;
}

export interface ResearchSearchRequest {
  q: string;
  jurisdictionId?: UUID;
  caseId?: UUID;
  mode?: "keyword" | "semantic" | "hybrid";
  topK?: number;
}

export interface FilingSubmitRequest {
  connectionId: UUID;
  caseId: UUID;
  documentId: UUID;
  filingType: string;
  idempotencyKey: string;
}
