export type UUID = string;
export type ISODateTime = string;

export type JurisdictionLevel = "federal" | "state" | "county" | "municipal" | "tribal";
export type CaseStatus = "intake" | "active" | "closed" | "archived";
export type AgentRole =
  | "lead_counsel_simulation"
  | "paralegal"
  | "researcher"
  | "rights_checker"
  | "plea_support"
  | "sentencing_support"
  | "probation_support"
  | "document_specialist"
  | "custom";

export interface Jurisdiction {
  id: UUID;
  countryCode: string;
  stateCode?: string;
  countyName?: string;
  courtName?: string;
  level: JurisdictionLevel;
  timezone: string;
}

export interface LegalCase {
  id: UUID;
  ownerUserId: UUID;
  jurisdictionId: UUID;
  title: string;
  status: CaseStatus;
  caseNumber?: string;
  openedAt: ISODateTime;
}

export interface SourceCitation {
  id: UUID;
  sourceType: "statute" | "case" | "rule" | "motion" | "court_record" | "user_document" | "web";
  title: string;
  citation?: string;
  url?: string;
  pinpoint?: string;
  retrievedAt: ISODateTime;
  sourceHash: string;
}

export interface Disclaimer {
  text: string;
  severity: "standard" | "high_risk";
  required: boolean;
}
