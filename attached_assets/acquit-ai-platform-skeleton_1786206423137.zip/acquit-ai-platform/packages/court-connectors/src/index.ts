import type { UUID } from "@acquit/contracts";

export interface CourtConnectorManifest {
  id: string;
  name: string;
  jurisdictionCodes: string[];
  capabilities: CourtCapability[];
  authModes: CourtAuthMode[];
  version: string;
}

export type CourtCapability =
  | "case_search"
  | "case_details"
  | "docket"
  | "filing_status"
  | "document_download"
  | "document_upload"
  | "efile"
  | "notifications";

export type CourtAuthMode = "public" | "oauth2" | "api_key" | "session" | "manual_user_auth";

export interface CourtCaseQuery {
  caseNumber?: string;
  partyName?: string;
  courtId?: string;
  filedAfter?: string;
  filedBefore?: string;
  page?: number;
  pageSize?: number;
}

export interface CourtCase {
  externalId: string;
  caseNumber?: string;
  title?: string;
  courtName?: string;
  filedAt?: string;
  status?: string;
  sourceUrl?: string;
}

export interface CourtDocketEntry {
  externalId: string;
  filedAt?: string;
  entryType?: string;
  description?: string;
  documentExternalId?: string;
  sourceUrl?: string;
}

export interface CourtDocument {
  externalId: string;
  filename: string;
  mimeType: string;
  sizeBytes?: number;
  downloadUrl?: string;
  content?: Uint8Array;
  sha256?: string;
}

export interface EfileRequest {
  caseExternalId: string;
  document: Uint8Array;
  filename: string;
  filingType: string;
  metadata?: Record<string, unknown>;
}

export interface EfileReceipt {
  submissionId: string;
  status: "accepted" | "rejected" | "pending";
  submittedAt: string;
  messages?: string[];
}

export interface CourtConnector {
  manifest(): CourtConnectorManifest;
  health(): Promise<{ ok: boolean; message?: string }>;
  searchCases(query: CourtCaseQuery): Promise<CourtCase[]>;
  getCase(externalCaseId: string): Promise<CourtCase>;
  getDocket(externalCaseId: string): Promise<CourtDocketEntry[]>;
  getDocument(externalDocumentId: string): Promise<CourtDocument>;
  submitFiling?(request: EfileRequest): Promise<EfileReceipt>;
}

export interface ConnectorContext {
  tenantId: UUID;
  userId: UUID;
  connectionId: UUID;
  idempotencyKey: string;
}

export interface CourtConnectorRegistry {
  register(connector: CourtConnector): void;
  get(connectorId: string): CourtConnector;
  list(): CourtConnectorManifest[];
}
