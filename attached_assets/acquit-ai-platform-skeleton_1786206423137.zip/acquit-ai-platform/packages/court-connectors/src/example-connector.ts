import type {
  CourtConnector, CourtConnectorManifest, CourtCaseQuery, CourtCase,
  CourtDocketEntry, CourtDocument
} from "./index";

export class ExampleCourtConnector implements CourtConnector {
  manifest(): CourtConnectorManifest {
    return {
      id: "example.public-court",
      name: "Example Public Court",
      version: "0.1.0",
      jurisdictionCodes: ["US-XX"],
      capabilities: ["case_search", "case_details", "docket", "document_download"],
      authModes: ["public"]
    };
  }

  async health() {
    return { ok: true };
  }

  async searchCases(_query: CourtCaseQuery): Promise<CourtCase[]> {
    throw new Error("Connector adapter not implemented.");
  }

  async getCase(_externalCaseId: string): Promise<CourtCase> {
    throw new Error("Connector adapter not implemented.");
  }

  async getDocket(_externalCaseId: string): Promise<CourtDocketEntry[]> {
    throw new Error("Connector adapter not implemented.");
  }

  async getDocument(_externalDocumentId: string): Promise<CourtDocument> {
    throw new Error("Connector adapter not implemented.");
  }
}
