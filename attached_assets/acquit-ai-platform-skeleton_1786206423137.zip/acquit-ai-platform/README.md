# Acquit.ai Platform — Production Monorepo Skeleton

This repository is the implementation foundation for the Acquit.ai legal self-representation platform.

## Architecture

- `apps/web` — Next.js web/mobile-first client
- `services/api` — authenticated application API / orchestration boundary
- `services/ai` — model routing, agent execution, RAG, evaluations
- `packages/agent-sdk` — agent contracts and lifecycle interfaces
- `packages/model-gateway` — provider-neutral LLM interface
- `packages/rag` — retrieval, reranking, citation/provenance contracts
- `packages/court-connectors` — court-system connector SDK
- `packages/db` — database types/query boundary
- `packages/contracts` — shared API/domain schemas
- `packages/security` — authorization, audit, redaction contracts
- `supabase/migrations` — PostgreSQL schema and RLS
- `infra` — Docker/local/deployment scaffolding

## Core principle

Acquit.ai can behave like a coordinated legal-support team, but the product must never represent an AI system as a licensed attorney. Legal outputs are evidence-grounded, jurisdiction-aware, traceable, and accompanied by the required educational/legal-information disclaimer.

## Build order

1. Run PostgreSQL/Supabase migrations.
2. Implement `packages/contracts`.
3. Implement Model Gateway adapters.
4. Implement RAG ingestion/retrieval.
5. Implement Agent SDK runtime.
6. Add court connectors one jurisdiction at a time.
7. Connect the web application.
8. Run security, citation, hallucination, and adversarial evaluations before production.
