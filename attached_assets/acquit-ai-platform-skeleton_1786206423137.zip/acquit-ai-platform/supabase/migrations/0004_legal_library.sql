create table if not exists legal.sources (
  id uuid primary key default gen_random_uuid(),
  source_type text not null
    check (source_type in ('statute','case','rule','motion','court_record','user_document','web')),
  title text not null,
  citation text,
  url text,
  publisher text,
  jurisdiction_id uuid references legal.jurisdictions(id),
  published_at timestamptz,
  retrieved_at timestamptz,
  source_hash text not null,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);

create unique index if not exists uq_sources_hash on legal.sources(source_hash);

create table if not exists legal.authorities (
  id uuid primary key default gen_random_uuid(),
  source_id uuid not null references legal.sources(id) on delete cascade,
  authority_type text not null,
  court_name text,
  docket_number text,
  case_name text,
  reporter_citation text,
  holding text,
  full_text text,
  precedential_status text,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_authorities_citation on legal.authorities(reporter_citation);
create index if not exists idx_authorities_case_name_trgm
  on legal.authorities using gin(case_name gin_trgm_ops);

create table if not exists legal.authority_relationships (
  id uuid primary key default gen_random_uuid(),
  citing_authority_id uuid not null references legal.authorities(id) on delete cascade,
  cited_authority_id uuid not null references legal.authorities(id) on delete cascade,
  relationship_type text not null default 'cites',
  pinpoint text,
  created_at timestamptz not null default now(),
  unique(citing_authority_id, cited_authority_id, relationship_type)
);

create table if not exists legal.parentheticals (
  id uuid primary key default gen_random_uuid(),
  authority_id uuid not null references legal.authorities(id) on delete cascade,
  text text not null,
  pinpoint text,
  created_at timestamptz not null default now()
);

create table if not exists legal.motions (
  id uuid primary key default gen_random_uuid(),
  jurisdiction_id uuid references legal.jurisdictions(id),
  title text not null,
  motion_type text not null,
  body text,
  source_id uuid references legal.sources(id),
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
