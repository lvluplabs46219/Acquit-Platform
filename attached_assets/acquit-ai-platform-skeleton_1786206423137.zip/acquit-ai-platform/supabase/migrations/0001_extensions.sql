create extension if not exists pgcrypto;
create extension if not exists vector;
create extension if not exists pg_trgm;

create schema if not exists app;
create schema if not exists legal;
create schema if not exists ai;
create schema if not exists connector;
