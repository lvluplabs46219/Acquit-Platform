create table if not exists app.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  locale text not null default 'en-US',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists legal.jurisdictions (
  id uuid primary key default gen_random_uuid(),
  country_code text not null default 'US',
  state_code text,
  county_name text,
  court_name text,
  level text not null check (level in ('federal','state','county','municipal','tribal')),
  timezone text not null default 'America/New_York',
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_jurisdictions_state_county
  on legal.jurisdictions(state_code, county_name);

create table if not exists legal.cases (
  id uuid primary key default gen_random_uuid(),
  owner_user_id uuid not null references auth.users(id) on delete restrict,
  jurisdiction_id uuid not null references legal.jurisdictions(id),
  title text not null,
  case_number text,
  status text not null default 'intake'
    check (status in ('intake','active','closed','archived')),
  case_type text,
  opened_at timestamptz not null default now(),
  closed_at timestamptz,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create index if not exists idx_cases_owner on legal.cases(owner_user_id);
create index if not exists idx_cases_case_number on legal.cases(case_number);

create table if not exists legal.case_parties (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references legal.cases(id) on delete cascade,
  party_type text not null check (party_type in ('defendant','plaintiff','petitioner','respondent','witness','other')),
  display_name text not null,
  is_user boolean not null default false,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_case_parties_case on legal.case_parties(case_id);
