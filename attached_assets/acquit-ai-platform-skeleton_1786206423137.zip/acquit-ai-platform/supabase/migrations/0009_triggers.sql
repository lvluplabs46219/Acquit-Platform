create or replace function app.touch_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

do $$
declare
  t text;
begin
  foreach t in array array[
    'app.profiles',
    'legal.cases',
    'legal.case_parties',
    'legal.charges',
    'legal.case_tasks',
    'legal.documents',
    'legal.authorities',
    'legal.motions',
    'ai.agents',
    'connector.registrations',
    'connector.connections',
    'connector.external_cases',
    'connector.filings'
  ]
  loop
    execute format(
      'drop trigger if exists trg_touch_updated_at on %s;
       create trigger trg_touch_updated_at before update on %s
       for each row execute function app.touch_updated_at();', t, t
    );
  end loop;
end $$;
