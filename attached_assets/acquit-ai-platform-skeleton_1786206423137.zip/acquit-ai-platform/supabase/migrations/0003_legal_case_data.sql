create table if not exists legal.charges (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references legal.cases(id) on delete cascade,
  statute_id uuid,
  count_number integer,
  charge_code text,
  name text not null,
  description text,
  severity text,
  status text not null default 'active',
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists legal.case_events (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references legal.cases(id) on delete cascade,
  event_type text not null,
  event_at timestamptz,
  title text not null,
  description text,
  source_document_id uuid,
  external_id text,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);

create index if not exists idx_case_events_case_time
  on legal.case_events(case_id, event_at);

create table if not exists legal.case_tasks (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references legal.cases(id) on delete cascade,
  assigned_agent_id uuid,
  title text not null,
  description text,
  status text not null default 'open',
  due_at timestamptz,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists legal.documents (
  id uuid primary key default gen_random_uuid(),
  owner_user_id uuid not null references auth.users(id) on delete restrict,
  case_id uuid references legal.cases(id) on delete cascade,
  filename text not null,
  mime_type text not null,
  storage_path text,
  sha256 text,
  byte_size bigint,
  processing_status text not null default 'uploaded'
    check (processing_status in ('uploaded','scanning','ocr','parsed','indexed','failed')),
  extracted_text text,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create index if not exists idx_documents_case on legal.documents(case_id);
create index if not exists idx_documents_sha256 on legal.documents(sha256);

create table if not exists legal.document_chunks (
  id uuid primary key default gen_random_uuid(),
  document_id uuid not null references legal.documents(id) on delete cascade,
  chunk_index integer not null,
  content text not null,
  token_count integer,
  page_start integer,
  page_end integer,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now(),
  unique(document_id, chunk_index)
);

create index if not exists idx_document_chunks_document on legal.document_chunks(document_id);
