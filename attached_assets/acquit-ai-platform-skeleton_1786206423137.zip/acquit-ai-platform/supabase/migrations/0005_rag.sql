create table if not exists ai.embeddings (
  id uuid primary key default gen_random_uuid(),
  document_id uuid references legal.documents(id) on delete cascade,
  chunk_id uuid references legal.document_chunks(id) on delete cascade,
  source_id uuid references legal.sources(id) on delete cascade,
  content text not null,
  embedding vector(1536) not null,
  model text not null,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now(),
  check (document_id is not null or source_id is not null)
);

create index if not exists idx_embeddings_vector
  on ai.embeddings using hnsw (embedding vector_cosine_ops);

create index if not exists idx_embeddings_document on ai.embeddings(document_id);
create index if not exists idx_embeddings_source on ai.embeddings(source_id);

create index if not exists idx_documents_text_gin
  on legal.documents using gin(to_tsvector('english', coalesce(extracted_text,'')));

create index if not exists idx_chunks_text_gin
  on legal.document_chunks using gin(to_tsvector('english', content));

create table if not exists ai.retrieval_traces (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  case_id uuid references legal.cases(id) on delete cascade,
  query text not null,
  mode text not null,
  filters jsonb not null default '{}',
  results jsonb not null default '[]',
  created_at timestamptz not null default now()
);

create table if not exists ai.source_claims (
  id uuid primary key default gen_random_uuid(),
  retrieval_trace_id uuid references ai.retrieval_traces(id) on delete cascade,
  claim_text text not null,
  source_id uuid references legal.sources(id),
  pinpoint text,
  support_score numeric(6,5),
  created_at timestamptz not null default now()
);
