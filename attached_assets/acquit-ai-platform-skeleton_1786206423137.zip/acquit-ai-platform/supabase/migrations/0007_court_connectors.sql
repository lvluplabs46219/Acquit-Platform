create table if not exists connector.registrations (
  id uuid primary key default gen_random_uuid(),
  connector_id text not null unique,
  name text not null,
  version text not null,
  jurisdiction_codes text[] not null default '{}',
  capabilities text[] not null default '{}',
  auth_modes text[] not null default '{}',
  active boolean not null default true,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists connector.connections (
  id uuid primary key default gen_random_uuid(),
  owner_user_id uuid not null references auth.users(id) on delete cascade,
  registration_id uuid not null references connector.registrations(id),
  external_account_ref text,
  encrypted_credentials_ref text,
  status text not null default 'active',
  expires_at timestamptz,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists connector.external_cases (
  id uuid primary key default gen_random_uuid(),
  connection_id uuid not null references connector.connections(id) on delete cascade,
  case_id uuid references legal.cases(id) on delete set null,
  external_id text not null,
  case_number text,
  title text,
  status text,
  source_url text,
  raw jsonb not null default '{}',
  last_synced_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(connection_id, external_id)
);

create table if not exists connector.sync_runs (
  id uuid primary key default gen_random_uuid(),
  connection_id uuid not null references connector.connections(id) on delete cascade,
  operation text not null,
  idempotency_key text not null,
  status text not null default 'running',
  records_seen integer not null default 0,
  records_changed integer not null default 0,
  error_message text,
  started_at timestamptz not null default now(),
  completed_at timestamptz,
  unique(connection_id, idempotency_key)
);

create table if not exists connector.filings (
  id uuid primary key default gen_random_uuid(),
  connection_id uuid not null references connector.connections(id) on delete cascade,
  case_id uuid references legal.cases(id) on delete set null,
  external_case_id text,
  document_id uuid references legal.documents(id),
  filing_type text not null,
  submission_id text,
  status text not null default 'pending',
  submitted_at timestamptz,
  response jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
