create table if not exists ai.agents (
  id uuid primary key default gen_random_uuid(),
  owner_user_id uuid references auth.users(id) on delete cascade,
  slug text not null,
  version text not null,
  name text not null,
  role text not null,
  description text,
  system_policy jsonb not null default '{}',
  tool_permissions jsonb not null default '[]',
  model_policy jsonb not null default '{}',
  is_system boolean not null default false,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(owner_user_id, slug, version)
);

create table if not exists ai.agent_runs (
  id uuid primary key default gen_random_uuid(),
  agent_id uuid not null references ai.agents(id),
  user_id uuid not null references auth.users(id) on delete restrict,
  case_id uuid references legal.cases(id) on delete cascade,
  parent_run_id uuid references ai.agent_runs(id),
  status text not null default 'running'
    check (status in ('running','completed','needs_input','blocked','failed')),
  input_hash text,
  prompt_hash text,
  model_provider text,
  model_name text,
  output_text text,
  citations jsonb not null default '[]',
  disclaimer text,
  metadata jsonb not null default '{}',
  started_at timestamptz not null default now(),
  completed_at timestamptz
);

create index if not exists idx_agent_runs_case on ai.agent_runs(case_id, started_at desc);
create index if not exists idx_agent_runs_user on ai.agent_runs(user_id, started_at desc);

create table if not exists ai.agent_tool_calls (
  id uuid primary key default gen_random_uuid(),
  run_id uuid not null references ai.agent_runs(id) on delete cascade,
  tool_name text not null,
  permission text not null,
  arguments jsonb not null default '{}',
  result jsonb,
  status text not null check (status in ('requested','success','denied','failed')),
  created_at timestamptz not null default now(),
  completed_at timestamptz
);

create table if not exists ai.model_invocations (
  id uuid primary key default gen_random_uuid(),
  run_id uuid references ai.agent_runs(id) on delete set null,
  provider text not null,
  model text not null,
  request_hash text,
  prompt_tokens integer,
  completion_tokens integer,
  total_tokens integer,
  latency_ms integer,
  status text not null,
  error_code text,
  created_at timestamptz not null default now()
);
