alter table app.profiles enable row level security;
alter table legal.cases enable row level security;
alter table legal.case_parties enable row level security;
alter table legal.charges enable row level security;
alter table legal.case_events enable row level security;
alter table legal.case_tasks enable row level security;
alter table legal.documents enable row level security;
alter table legal.document_chunks enable row level security;
alter table ai.retrieval_traces enable row level security;
alter table ai.agent_runs enable row level security;
alter table ai.agent_tool_calls enable row level security;
alter table ai.agents enable row level security;
alter table connector.connections enable row level security;
alter table connector.external_cases enable row level security;
alter table connector.filings enable row level security;

create policy "profile self read"
on app.profiles for select
using (id = auth.uid());

create policy "profile self update"
on app.profiles for update
using (id = auth.uid());

create policy "case owner read"
on legal.cases for select
using (owner_user_id = auth.uid());

create policy "case owner insert"
on legal.cases for insert
with check (owner_user_id = auth.uid());

create policy "case owner update"
on legal.cases for update
using (owner_user_id = auth.uid())
with check (owner_user_id = auth.uid());

create policy "case owner delete"
on legal.cases for delete
using (owner_user_id = auth.uid());

create policy "case parties via owned case"
on legal.case_parties for all
using (exists (
  select 1 from legal.cases c
  where c.id = case_parties.case_id and c.owner_user_id = auth.uid()
))
with check (exists (
  select 1 from legal.cases c
  where c.id = case_parties.case_id and c.owner_user_id = auth.uid()
));

create policy "charges via owned case"
on legal.charges for all
using (exists (
  select 1 from legal.cases c
  where c.id = charges.case_id and c.owner_user_id = auth.uid()
))
with check (exists (
  select 1 from legal.cases c
  where c.id = charges.case_id and c.owner_user_id = auth.uid()
));

create policy "events via owned case"
on legal.case_events for all
using (exists (
  select 1 from legal.cases c
  where c.id = case_events.case_id and c.owner_user_id = auth.uid()
))
with check (exists (
  select 1 from legal.cases c
  where c.id = case_events.case_id and c.owner_user_id = auth.uid()
));

create policy "documents owner"
on legal.documents for all
using (owner_user_id = auth.uid())
with check (owner_user_id = auth.uid());

create policy "chunks via owned document"
on legal.document_chunks for all
using (exists (
  select 1 from legal.documents d
  where d.id = document_chunks.document_id and d.owner_user_id = auth.uid()
))
with check (exists (
  select 1 from legal.documents d
  where d.id = document_chunks.document_id and d.owner_user_id = auth.uid()
));

create policy "retrieval traces owner"
on ai.retrieval_traces for all
using (user_id = auth.uid())
with check (user_id = auth.uid());

create policy "agent runs owner"
on ai.agent_runs for all
using (user_id = auth.uid())
with check (user_id = auth.uid());

create policy "agent tool calls via run owner"
on ai.agent_tool_calls for all
using (exists (
  select 1 from ai.agent_runs r
  where r.id = agent_tool_calls.run_id and r.user_id = auth.uid()
))
with check (exists (
  select 1 from ai.agent_runs r
  where r.id = agent_tool_calls.run_id and r.user_id = auth.uid()
));

create policy "custom agents owner"
on ai.agents for all
using (is_system or owner_user_id = auth.uid())
with check (is_system or owner_user_id = auth.uid());

create policy "connector connections owner"
on connector.connections for all
using (owner_user_id = auth.uid())
with check (owner_user_id = auth.uid());

create policy "external cases via connection owner"
on connector.external_cases for all
using (exists (
  select 1 from connector.connections c
  where c.id = external_cases.connection_id and c.owner_user_id = auth.uid()
))
with check (exists (
  select 1 from connector.connections c
  where c.id = external_cases.connection_id and c.owner_user_id = auth.uid()
));

create policy "filings via connection owner"
on connector.filings for all
using (exists (
  select 1 from connector.connections c
  where c.id = filings.connection_id and c.owner_user_id = auth.uid()
))
with check (exists (
  select 1 from connector.connections c
  where c.id = filings.connection_id and c.owner_user_id = auth.uid()
));

-- Legal library records are intentionally public/read-only at the application level;
-- write access belongs to trusted ingestion workers, not browser users.
