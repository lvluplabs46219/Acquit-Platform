# Web App

Next.js client application.

Rules:
- Never call model providers directly from the browser.
- All AI requests go through authenticated API routes.
- Never expose provider API keys.
- Render source citations/provenance with substantive legal outputs.
- Keep the educational/legal-information disclaimer persistent.
