export default function HomePage() {
  return (
    <main>
      <h1>Acquit.ai</h1>
      <p>AI-powered legal information and self-representation support.</p>
      <p>
        This information is for educational purposes only and does not constitute
        legal advice. Consult a licensed attorney in your jurisdiction.
      </p>
    </main>
  );
}
